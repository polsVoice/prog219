jQuery EZStorage
==================

jQuery EZStorage is a plugin that simplifies access to HTML5 storages & cookies.  The plugin handles determining where and how to store and retrieve data; in HTML5 Storage if it is available, or defaults to cookies.

CHANGELOG
-------------------------
###1.2.2 
damn typos and some more commenting

###1.2.1 
numeric options.expires value now being set correctly when decimal
values passed, eg. .25 or 20.662; also clarified some commenting

###1.2.0 
added settings property to global object, and options parameter to functions;  automatic Date parsing for expiration values.

###1.1.0 
added shorthand version of functions

###1.0.0 
Initial version